﻿using System;
using System.Linq;

namespace SimensTest
{

    public class FileSystem
    {
        public string CurrentFolderName { get; set; }
        public string Parent { get; set; }
        public FileSystem[] ChildFolder { get; set; }

    }

    public static class SharedFileSystem
    {
        static SharedFileSystem()
        {
            Sharedob = new FileSystem();
            Sharedob.ChildFolder = new FileSystem[2] { null, null };
            Sharedob.Parent = "users";
            Sharedob.CurrentFolderName = "chintan.rathod1";
        }
        public static FileSystem Sharedob { get; set; }
    }
    public interface IfileOperation
    {
        void PerformOperation(string input);
    }
    public class MDOperation : IfileOperation
    {
        public void PerformOperation(string input) 
        {
            var ChildFolderLength = default(int);
            if (SharedFileSystem.Sharedob.ChildFolder != null)
            {
                if (SharedFileSystem.Sharedob.ChildFolder[0] != null)
                    ChildFolderLength = 1;
            }


            FileSystem foldertoAdd = new FileSystem();
            foldertoAdd.Parent = SharedFileSystem.Sharedob.CurrentFolderName;
            foldertoAdd.CurrentFolderName = input.Split(" ")[1];
            foldertoAdd.ChildFolder = new FileSystem[2] { null, null };
            SharedFileSystem.Sharedob.ChildFolder.SetValue(foldertoAdd, ChildFolderLength);
        }
    }
    public class cdOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {

            Console.WriteLine(SharedFileSystem.Sharedob.Parent);
            SharedFileSystem.Sharedob.Parent = input.Split(" ")[1];
        }
    }


    public class cdDotDotOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {
            Console.WriteLine(SharedFileSystem.Sharedob.CurrentFolderName);
            SharedFileSystem.Sharedob.CurrentFolderName = SharedFileSystem.Sharedob.Parent;
        }
    }
    public class MKFileOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {
            SharedFileSystem.Sharedob.CurrentFolderName = input.Split(" ")[1];
            SharedFileSystem.Sharedob.ChildFolder = null;
        }
    }
    public class DirOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {
            foreach (var chdFolder in SharedFileSystem.Sharedob.ChildFolder)
            {
                if (chdFolder != null && chdFolder.CurrentFolderName != null)
                    Console.WriteLine(chdFolder.CurrentFolderName);
            }
        }
    }
    public class DirSOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {
            throw new NotImplementedException();
        }
    }
    public class ExitOperation : IfileOperation
    {
        public void PerformOperation(string input)
        {
            Console.WriteLine("exit operation");
        }
    }


    public class FileOperationFactory
    {
        int choice { get; set; }
        public FileOperationFactory(int choice)
        {
            this.choice = choice;
        }

        public IfileOperation GetFileOperationObjct()
        {
            IfileOperation ob = null;

            switch (choice)
            {
                case 1:
                    ob = new MDOperation();
                    break;
                case 2:
                    ob = new cdOperation();
                    break;
                case 3:
                    ob = new cdDotDotOperation();
                    break;
                case 4:
                    ob = new MKFileOperation();
                    break;
                case 5:
                    ob = new DirOperation();
                    break;
                case 6:
                    ob = new DirSOperation();
                    break;
                case 7:
                    ob = new ExitOperation();
                    break;

            }
            return ob;
        }


    }


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Current Folder: " + SharedFileSystem.Sharedob.CurrentFolderName);
            Console.WriteLine("enter command");

            int choice = default(int);
            string input = Console.ReadLine();

            if (input.Contains("md"))
                choice = 1;
            else if (input.Contains("cd") && !input.Contains(".."))
                choice = 2;
            else if (input.Contains("cd") && input.Contains(".."))
                choice = 3;
            else if (input.Contains("mf"))
                choice = 4;
            else if (input.Contains("dir") && !input.Contains("/s"))
                choice = 5;
            else if (input.Contains("dir") && input.Contains("/s"))
                choice = 6;
            else if (input.Contains("exit"))
                choice = 7;
            else
                Console.WriteLine("Invalid input");

            FileOperationFactory factoryob = new FileOperationFactory(choice);
            IfileOperation ob = factoryob.GetFileOperationObjct();
            ob.PerformOperation(input);

            Console.ReadLine();
        }
    }
}
